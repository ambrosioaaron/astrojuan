<div class="jumbotron">
    <h1>Articles</h1>
    <p class="lead">(text here)</p>
    
    <div class="row">
        <div class="col-md-4">
            <h2>Article1</h2>
            <p>
                Place article short description here. Place article short description here. Place article short description here.
            </p>
            <p><a class="btn btn-default" href="#">Read article &raquo;</a></p>
        </div>
		<div class="col-md-4">
            <h2>Article2</h2>
            <p>
                Place article short description here. Place article short description here. Place article short description here.
            </p>
            <p><a class="btn btn-default" href="#">Read article &raquo;</a></p>
        </div>
        <div class="col-md-4">
            <h2>Article2</h2>
            <p>
                Place article short description here. Place article short description here. Place article short description here.
            </p>
            <p><a class="btn btn-default" href="#">Read article &raquo;</a></p>
        </div>
    </div>
</div>

