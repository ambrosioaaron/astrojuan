<div class="jumbotron">
    <h3>Error</h3>
    <p class="lead">An unexpected error has occurred.</p>
</div>