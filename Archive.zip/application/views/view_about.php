<div class="jumbotron">
    <h2>About AstroJuan</h2>
</div>