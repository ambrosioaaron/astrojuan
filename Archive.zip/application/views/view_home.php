
<div class="jumbotron">
    <h1>AstroJuan</h1>
    <p class="lead">Place website description here. Place website description here. Place website description here. </p>
    <p><a href="#" class="btn btn-success btn-large">Learn more &raquo;</a></p>
</div>

<div class="row">
    <div class="col-md-4 homeFeatured">
        <h2>Events</h2>
        <p>
            Event Title<br />
            Place event short description here. Place event short description here. Place event short description here.
        </p>
        <a class="btn btn-default" href="/events">See more &raquo;</a>
    </div>
    <div class="col-md-4 homeFeatured">
        <h2>Articles</h2>
        <p>
            Article Title<br />
            Place article short description here. Place article short description here. Place article short description here.
        </p>
        <a class="btn btn-default" href="/articles">See more &raquo;</a>
    </div>
    <div class="col-md-4 homeFeatured">
        <h2>Tips</h2>
        <p>Place tips description here. Place tips description here. Place tips description here. </p>
        <a class="btn btn-default" href="#">See more &raquo;</a>
    </div>
</div>