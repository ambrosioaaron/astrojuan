<div class="jumbotron">
    <h1>Events</h1>
    <p class="lead">(text here)</p>
    
    <div class="row">
        <div class="col-md-4">
            <h2>Event1</h2>
            <p>
                Place event short description here. Place event short description here. Place event short description here.
            </p>
            <p><a class="btn btn-default" href="#">View Details &raquo;</a></p>
        </div>
		<div class="col-md-4">
            <h2>Event2</h2>
            <p>
                Place event short description here. Place event short description here. Place event short description here.
            </p>
            <p><a class="btn btn-default" href="#">View Details &raquo;</a></p>
        </div>
        <div class="col-md-4">
            <h2>Event3</h2>
            <p>
                Place event short description here. Place event short description here. Place event short description here.
            </p>
            <p><a class="btn btn-default" href="#">View Details &raquo;</a></p>
        </div>
    </div>
</div>

